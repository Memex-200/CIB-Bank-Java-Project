/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CIB;
import javax.swing.JFrame;

/**
 *
 * @author rahmaaa
 */
public class CIB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic her
        JFrame frame = new GUI();
        frame.setVisible(true);
        frame.setResizable(false);
        frame.setLocation(100,100);
    }
    
    public static  int Add(int num1 , int num2){
        return num1-num2;
    }
    
}
