/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CIB;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Eman Hassan
 */
public class GUITest {
    
    public GUITest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of check_login method, of class GUI.
     */
    @Test
    public void testCheck_login() {
        System.out.println("check_login");
        String un = "";
        String pass = "";
        GUI instance = new GUI();
        boolean expResult = false;
        boolean result = instance.check_login(un, pass);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class GUI.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        GUI.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of reg method, of class GUI.
     */
    @Test
    public void testReg() {
        System.out.println("reg");
        String first_name = "Rana";
        String last_name = "Abdelsalam";
        int age = 20;
        String phone = "01236548895";
        String address = "Assuit";
        String city = "Assuit";
        String country = "Egypt";
        String gender = "Female";
        String username = "rana";
        String password = "546987";
        String confirm_password = "546987";
        GUI instance = new GUI();
        boolean expResult = true;
        boolean result = instance.reg(first_name, last_name, age, phone, address, city, country, gender , username , password , confirm_password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}
